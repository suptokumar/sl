<?php 
$number="0163733554h";
if (preg_match('/^(01[3-9]\d{8})$/', $number) )
			echo "Number is valid";
		else echo "Number is not valid";



 ?>

 