<form action="">
	<input type="text" name="so">
</form>