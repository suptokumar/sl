<?php 
$db = mysqli_connect("localhost","root","","paipixel") or die("Failed To connect to the Server");
date_default_timezone_set("Asia/Dhaka");
?>