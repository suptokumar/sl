<?php 
echo '<script src="js/jquery.js"></script>';
echo '<script src="js/jquery-ui.min.js"></script>';
echo '<script src="js/jquery.datetimepicker.min.js"></script>';
echo '<script src="js/home.js"></script>';
echo '<script src="dist/owl.carousel.min.js"></script>';
?>