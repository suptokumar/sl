<?php 
session_start();
include_once 'header.php';
get_header("PaiPixel | Biggest Student-Teacher Interactive Platform","","");
echo "<body>";
echo '<div class="container">';
get_nav();
echo '</div>';
get_footer();
get_body();
echo "</body>";
echo "</html>";
?>
